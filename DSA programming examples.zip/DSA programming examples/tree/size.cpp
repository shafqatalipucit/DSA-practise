#include <iostream>
using namespace std;
class node
{
    int data;
    node *left;
    node *right;

public:
node* newNode(int data) 
    {
        node* Node=new node();
        Node->data=data;
        Node->left=NULL;
        Node->right=NULL;
        return Node;
    }
    int size(node* Node)
    {
        if(Node==NULL)
        {
            return 0;
        }
        else
        { 
            return  size(Node->left)+1+size(Node->right);
        }
    }
};
int main()
{
    cout << "hellow world";
    return 0;
}