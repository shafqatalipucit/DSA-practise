#include <iostream>
using namespace std;
class node
{
    int data;
    node *next;

public:
    node()
    {
        int data = 0;
        next = nullptr;
    }
    node(int data)
    {
        this->data = data;
        this->next = nullptr;
    }
    ~node()
    {
        cout << "node destructor" << endl;
    }
    friend class list;
};
class list
{
private:
    node *head;

public:
    list()
    {
        head = nullptr;
    }
    list(const node *head)
    {
        head = head;
    }
    void insertAtEnd(int data)
    {
        node *newnode = new node(data);
        if (head == nullptr)
        {
            head = newnode;
            newnode->next = nullptr;
        }
        else
        {
            node *curNode = head;
            while (curNode->next != nullptr)
            {
                curNode = curNode->next;
            }
            curNode->next = newnode;
            newnode->next = nullptr;
        }
        cout << "========================================================" << endl
             << "inserted successfully" << endl;
    }
    void traverselist()
    {
        cout << "=============================================" << endl;
        if (head == nullptr)
        {
            cout << " list is empty" << endl;
        }
        else
        {
            node *curNode = head;
            while (curNode != nullptr)

            {
                cout << curNode->data << " ";
                curNode = curNode->next;
            }
            cout << endl;
        }
    }
    void deleteAtEnd()
    {
        if (head == nullptr)
        {
            cout << "list is empty" << endl;
            return;
        }
        if (head->next == nullptr)
        {
            delete head;
            head = nullptr;
            return;
        }
        else
        {
            node *curNode = head;
            node *prevNode = curNode;
            while (curNode->next != nullptr)
            {
                prevNode = curNode;
                curNode = curNode->next;
            }
            delete curNode;
            curNode = nullptr;
            prevNode->next = nullptr;
        }
    }
    int sizeOfList()
    {
        int count = 1;
        if (head == nullptr)
        {
            cout << "list is empty" << endl;
            return 0;
        }
        node *curNode = head;
        while (curNode->next != nullptr)
        {
            count++;
            curNode = curNode->next;
        }
        cout << "size is :" << count << endl;
        return count;
    }
    void middlePrint()
    {
        node *curNode = head;
        int middle = (this->sizeOfList()) / 2;
        for (int i = 0; i < middle; i++)
        {
            curNode = curNode->next;
        }
        cout << "Middle element is :" << endl
             << curNode->data << endl;
    }
    void rotatelist(int k)
    {
        if (head == nullptr || head->next == nullptr)
        {
            cout << "rotation is not possible" << endl;
        }
        else
        {
            node *curNode = head;
            int size = sizeOfList();
            int connection_break = size - k;
            for (int i = 1; i < connection_break; i++)
            {
                curNode = curNode->next;
            }

            node *newhead = curNode->next;
            node *newCurrent = newhead;
            while (newCurrent->next != nullptr)
            {
                newCurrent = newCurrent->next;
            }
            curNode->next = nullptr;
            newCurrent->next = head;
            head = newhead;
            traverselist();
        }
    }
    void deleteMiddle()
    {
        node *curnode = head;
        node *next = nullptr;
        int middle = (this->sizeOfList() + 1) / 2;
        for (int i = 1; i < middle; i++)
        {
            curnode = curnode->next;
            next = curnode->next;
        }
        node *delnode = next;
        next = delnode->next;
        curnode->next = next;
        delete delnode;
        delnode = nullptr;
        cout << "delete middle ";
        traverselist();
    }
    void sortList()
    {
        bool swapped = true;
        if (head == nullptr || head->next == nullptr)
        {
            cout << "rotation is not possible" << endl;
            return;
        }

        else
        {
            while (swapped)
            {
                swapped = false;
                node *curnode = head;
                while (curnode->next != nullptr)
                {
                    if (curnode->data > curnode->next->data)
                    {
                        int temp = curnode->data;
                        curnode->data = curnode->next->data;
                        curnode->next->data = temp;
                        swapped = true;
                    }
                    curnode = curnode->next;
                }
            }
        }
        traverselist();
    }
    void deleteSortedMiddle()
    {
        if (head == nullptr || head->next == nullptr)
        {
            cout << "rotation is not possible" << endl;
            return;
        }
        else
        {
            int middle = sizeOfList() / 2;
            this->sortList();
            node *curnode = head;
            node *prevnode = nullptr;
            for (int i = 0; i < middle - 1; i++)
            {
                prevnode = curnode;
                curnode = curnode->next;
            }
            node *delnode = curnode->next;
            curnode->next = delnode->next;
            delete delnode;
            delnode = nullptr;
        }
        traverselist();
    }
    void removeduplicate()
    {
        if (head == nullptr || head->next == nullptr)
        {
            cout << "Not deletion possible" << endl;
        }
        else
        {
            node *curnode = head;

            while (curnode != nullptr)
            {
                node *prev = nullptr;
                node *count = curnode->next;
                bool duplicateFound = false; // Flag to indicate if a duplicate was found
                while (count != nullptr)
                {
                    if (curnode->data == count->data)
                    {
                        if (prev == nullptr)
                        {
                            head = head->next; // Update head if duplicate is first node
                        }
                        else
                        {
                            prev->next = count->next;
                        }
                        node *del = count;
                        count = count->next;
                        delete del;
                        duplicateFound = true;
                    }
                    else
                    {
                        prev = count;
                        count = count->next;
                    }
                }

                if (duplicateFound)
                {
                    cout << "Duplicate deleted successfully" << endl;
                }

                curnode = curnode->next;
            }
        }
        traverselist();
    }
    // delete n after m
    void deletefirst()
    {
        node *curNode = head;
        head = head->next;
        delete curNode;
        this->traverselist();
    }

int NumberOccurence(int data)
{
    node *curnode=head;
    int count=0;
    while (curnode)
    {
        if(curnode->data==data)
        {
            count++;
        }
        curnode=curnode->next;
    }
    return count;
}
    void MergeRandom(list *l2)
    {
        if (this->head == nullptr || l2->head == nullptr)
        {
            cout << "merging is not possible" << endl;
            return;
        }
        else
        {
            node *curNode1 = this->head;
            node *curNode2 = l2->head;
            while (curNode1 != nullptr && curNode2!= nullptr)
            {

                node *next1 = curNode1->next;
                node *next2 = curNode2->next;
                curNode1->next = curNode2;
                curNode2->next = next1;
                curNode1 = next1;
                curNode2 = next2;
            }
        }
        this->traverselist();
    }
    void mergeList(list *l2)
    {

        node *curNode1 = this->head;
        node *curNode2 = l2->head;
        if (curNode1 == nullptr || curNode2 == nullptr)
        {
            cout << "one list is empty of the  both" << endl;
            return;
        }
        while (curNode1->next != nullptr)
        {
            curNode1 = curNode1->next;
        }
        curNode1->next = l2->head;
        this->traverselist();
    }

    void deleteSpecific(int k)
    {
        if (head == nullptr)
        {
            cout << "list is empty" << endl;
            return;
        }
        else if (head->next == nullptr)
        {
            delete head;
            cout << " head deleted " << endl;
            return;
        }
        else
        {
            node *prev = nullptr;
            node *curNode = head;
            node *del = nullptr;
            while (curNode->data != k)
            {
                prev = curNode;
                curNode = curNode->next;
            }
            del = curNode;
            prev->next = del->next;
            delete del;
            traverselist();
        }
    }
    void deleteLastOccurence(int key)
    {
        if (head == nullptr)
        {
            cout << "list is empty" << endl;
            return;
        }
        else
        {
            node *curNode = head;
            node *delNode = nullptr;
            node *prev = nullptr;
            node *predel = nullptr;
            while (curNode->next != nullptr)
            {
                if (curNode->data == key)
                {
                    delNode = curNode;
                    predel = prev;
                }
                prev = curNode;
                curNode = curNode->next;
            }
            if (delNode != nullptr)
            {
                predel->next = delNode->next;
                delete delNode;
                delNode = nullptr;
            }
            else
            {
                cout << "delete is not possible" << endl;
            }
        }
        traverselist();
    }
    void reverseList()
    {
        if (head == nullptr || head->next == nullptr)
        {
            cout << "reversing is not possible" << endl;
            return;
        }
        else
        {
            node *prev = nullptr;
            node *curNode = head;
            node *next = nullptr;
            while (curNode != nullptr)
            {
                next = curNode->next;
                curNode->next = prev;
                prev = curNode;
                curNode = next;
            }
            head = prev;
            traverselist();
        }
    }

    ~list()
    {
        cout << "list destructor" << endl;
    }
};

int main()
{
    list l1, l2;
    //  li.insertAtEnd(34545);
    // li.insertAtEnd(235);
    l1.insertAtEnd(1);
    l1.insertAtEnd(2);
    l1.insertAtEnd(3);
    l1.insertAtEnd(3);
    l1.insertAtEnd(3);
    l1.insertAtEnd(3);
    int count=l1.NumberOccurence(3);
    cout<<"number occurs for "<<" "<<count<<"times"<<endl;
    // l2.insertAtEnd(7);
    // l2.insertAtEnd(8);
    //l1.traverselist();
    //l2.traverselist();
    //l1.MergeRandom(&l2);
    // l1.mergeRandom(&l2);
    // l1.mergeList(&l2);
    // list l3;

    // l3.traverselist();
    //  li.deletefirst();
    //  li.traverselist();
    //  li.removeduplicate();
    //  li.deleteInCenter(33);
    //   li.deleteLastOccurence(33);
    //  li.sortList();
    //  li.deleteSortedMiddle();
    //  li.deleteMiddle();
    //   li.rotatelist(3);
    //   li.reverseList();
    //   li.middlePrint();

    // li.traverselist();
    //  li.deleteAtEnd();
    //  li.traverselist();
    // int size = li.sizeOfList();
    // cout << "size of the list is :" << size << endl;

    return 0;
}