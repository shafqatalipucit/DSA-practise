#include <iostream>
#include <cmath>

static int a = 0;
// Function to calculate the factorial of a number
int factorial(int n) {
    std::cout << "Value of 'a' in factorial: " << a << std::endl;
    if (n == 0 || n == 1) {
        return 1;
    }
    return n * factorial(n - 1);
}

// Function to find the maximum of two numbers
int max(int a, int b) {
    std::cout << "Value of 'a' in max: " << a << std::endl;
    return (a > b) ? a : b;
}

// Function to check if a number is prime
bool isPrime(int num) {
    std::cout << "Value of 'a' in isPrime: " << a << std::endl;
    if (num <= 1) {
        return false;
    }
    for (int i = 2; i <= sqrt(num); ++i) {
        if (num % i == 0) {
            return false;
        }
    }
    return true;
}

// Function to calculate the nth Fibonacci number
int fibonacci(int n) {
    std::cout << "Value of 'a' in fibonacci: " << a << std::endl;
    if (n <= 0) {
        return 0;
    } else if (n == 1) {
        return 1;
    } else {
        return fibonacci(n - 1) + fibonacci(n - 2);
    }
}

// Function to print a given pattern
void printPattern(int rows) {
    std::cout << "Value of 'a' in printPattern: " << a << std::endl;
    for (int i = 1; i <= rows; ++i) {
        for (int j = 1; j <= i; ++j) {
            std::cout << j << " ";
        }
        std::cout << std::endl;
    }
}

// Function to reverse a given number
int reverseNumber(int num) {
    std::cout << "Value of 'a' in reverseNumber: " << a << std::endl;
    int reversed = 0;
    while (num != 0) {
        int digit = num % 10;
        reversed = reversed * 10 + digit;
        num /= 10;
    }
    return reversed;
}

// Function to calculate the power of a number
double power(double base, int exponent) {
    std::cout << "Value of 'a' in power: " << a << std::endl;
    double result = 1.0;
    for (int i = 0; i < exponent; ++i) {
        result *= base;
    }
    return result;
}

int main() {
    int num = 5;
    std::cout << "Factorial of " << num << " is: " << factorial(num) << std::endl;

    int a = 10, b = 20;
    std::cout << "Max of " << a << " and " << b << " is: " << max(a, b) << std::endl;

    int checkPrime = 17;
    if (isPrime(checkPrime)) {
        std::cout << checkPrime << " is a prime number." << std::endl;
    } else {
        std::cout << checkPrime << " is not a prime number." << std::endl;
    }

    int fibNum = 7;
    std::cout << "Fibonacci number at position " << fibNum << " is: " << fibonacci(fibNum) << std::endl;

    int patternRows = 5;
    std::cout << "Printing pattern with " << patternRows << " rows:" << std::endl;
    printPattern(patternRows);

    int numberToReverse = 12345;
    std::cout << "Reversed number of " << numberToReverse << " is: " << reverseNumber(numberToReverse) << std::endl;

    double base = 2.0;
    int exponent = 5;
    std::cout << base << " raised to the power of " << exponent << " is: " << power(base, exponent) << std::endl;

    return 0;
}
