#include <iostream>
using namespace std;

class Node
{
    int data;  // Data stored in the node
    Node *ptr; // Pointer to the next node

public:
    // Constructor to initialize data and pointer
    Node(int data, Node *ptr)
    {
        this->data = data; // Assign data
        this->ptr = ptr;   // Assign pointer
    }

    // Destructor to deallocate memory when a node is destroyed
    ~Node()
    {
        cout << "\n"
             << "Node destructor is called"
             << "\n";
    }

    // Declare the list class as a friend to allow access to private members
    friend class list;
};

class list
{
private:
    Node *head; // Pointer to the first node in the list

public:
    // Constructor to initialize the head pointer
    list()
    {
        head = NULL; // Initialize head to NULL, indicating an empty list
    }

    // Function to check if the list is empty
    bool isEmpty()
    {
        return !head; // Return true if head is NULL, false otherwise
    }

    // Function to insert a new node at the end of the list
    void InsertAtEnd(int data)
    {
        Node *new_node = new Node(data, NULL); // Create a new node with the given data and NULL pointer
        Node *current = head;                  // Initialize current pointer to traverse the list

        if (head == NULL)
        {
            head = new_node;      // If the list is empty, set the new node as the head
            new_node->ptr = NULL; // Set the next pointer of the new node to NULL
        }
        else
        {
            while (current->ptr != NULL)
            {
                current = current->ptr; // Traverse the list until the last node
            }
            current->ptr = new_node; // Set the next pointer of the last node to the new node
            new_node->ptr = NULL;    // Set the next pointer of the new node to NULL, indicating the end of the list
        }
    }
    void middle(int count)
    {
        int mid = (count / 2);
        Node *current = head;
        for (int i = 0; i < mid; i++)
        {
            current = current->ptr;
        }
        cout << "The middle element is :"
             << "\n";
        cout << current->data << "\n";
    }

    // Function to traverse and display the elements of the list
    void traverse()
    {
        Node *curNode = head; // Start traversing from the head node
        int count = 0;        // Initialize a counter to count the number of nodes

        if (head == NULL)
        {
            cout << "list is empty"
                 << "\n"; // If the list is empty, print a message
        }
        else
        {
            while (curNode != NULL)
            {
                cout << curNode->data << "\t"; // Print the data of the current node
                curNode = curNode->ptr;        // Move to the next node
                count++;                       // Increment the counter
            }
        }

        cout << "\n"
             << "Number of nodes in list are " << count << "\n"; // Print the total number of nodes in the list
             middle(count);
    }
    void checkCircular()
    {
        Node *curNode=head;
        while(1)
        {
         if(curNode->ptr==head)
         {

            cout<<"Found this is a circular list"<<"\n";
            break;
         }
         else{
            curNode=curNode->ptr;
            if(curNode->ptr==NULL)
            {
                cout<<"Null found it is not a circular list!"<<"\n";
            }
         }
        }

    }
    void  Convert_circular()
    {
        Node* curNode=head;
        while(curNode->ptr!=NULL)
        {
            curNode=curNode->ptr;
        }
        curNode=head;
        cout<<"Converted to circular linklist"<<"\n";
    }

    // Destructor to deallocate memory when the list object is destroyed
    ~list()
    {
        cout << "\n"
             << "List desctructor is called...."
             << "\n";
    }
};

int main()
{
    list l1; // Create an instance of the list class

    // Insert elements into the list
    l1.InsertAtEnd(22);
    l1.InsertAtEnd(23);
    l1.InsertAtEnd(24);
    l1.InsertAtEnd(25);
    l1.InsertAtEnd(26);
    l1.InsertAtEnd(27);
    l1.InsertAtEnd(28);
    l1.InsertAtEnd(29);
    l1.InsertAtEnd(2);
    l1.InsertAtEnd(3);
    l1.InsertAtEnd(42);
    l1.InsertAtEnd(62);
    l1.InsertAtEnd(72);
    l1.InsertAtEnd(82);
    l1.InsertAtEnd(92);

    // Traverse and display the elements of the list
    //l1.traverse();
    //l1.checkCircular();
    l1.Convert_circular();

    return 0;
}
