#include <iostream>
using namespace std;

class Node
{
    int data; // Data stored in the node
    Node *next;
    Node *prev;

public:
    // Constructor to initialize data and pointer
    Node(int data, Node *next, Node *prev)
    {
        this->data = data; // Assign data
        this->next = next; // Assign pointer
        this->prev = prev;
    }

    // Destructor to deallocate memory when a node is destroyed
    ~Node()
    {
        cout << "\n"
             << "Node destructor is called"
             << "\n";
    }

    // Declare the list class as a friend to allow access to private members
    friend class list;
};

class list
{
private:
    Node *head; // Pointer to the first node in the list

public:
    // Constructor to initialize the head pointer
    list()
    {
        head = NULL; // Initialize head to NULL, indicating an empty list
    }

    // Function to check if the list is empty
    bool isEmpty()
    {
        return !head; // Return true if head is NULL, false otherwise
    }

    // Function to insert a new node at the end of the list
    void InsertAtEnd(int data)
    {
        Node *new_node = new Node(data, NULL, NULL); // Create a new node with the given data and NULL pointer
        Node *current = head;                        // Initialize current pointer to traverse the list

        if (head == NULL)
        {
            head = new_node; // If the list is empty, set the new node as the head
            new_node->next = NULL;
            new_node->prev = NULL; // Set the next pointer of the new node to NULL
        }
        else
        {
            while (current->next != NULL)
            {
                current = current->next; // Traverse the list until the last node
            }

            current->next = new_node; // Set the next pointer of the last node to the new node
            new_node->prev = current;
            new_node->next = NULL; // Set the next pointer of the new node to NULL, indicating the end of the list
        }

        cout << "Inserted successfully"
             << "\n";
    }

    // Function to traverse and display the elements of the list

    void Reversedoubly()
    {
        if (head == NULL)
        {
            cout << "List is empty"
                 << "\n";
            return;
        }

        Node *curNode = head;
        while (curNode->next != NULL)
        {
            curNode = curNode->next;
        }
        cout << "Reversed doubly "
             << "\n";
        while (curNode != NULL)
        {
            cout << curNode->data << "\n";
            curNode = curNode->prev;
        }
    }

    void deleteNode(int data)
    {
        if (head == NULL)
        {
            cout << "List is empty"
                 << "\n";
            return;
        }

        Node *current = head;
        Node *prev = NULL;

        // Traverse the list to find the node with the specified data
        while (current != NULL && current->data != data)
        {
            prev = current;
            current = current->next;
        }

        // If the node with the specified data is found
        if (current != NULL)
        {
            // If the node to be deleted is the head node
            if (prev == NULL)
            {
                head = head->next; // Update head to the next node
                if (head != NULL)
                {
                    head->prev = NULL; // Update the new head's previous pointer to NULL
                }
                delete current; // Delete the node
            }
            else
            {
                prev->next = current->next; // Update the previous node's next pointer
                if (current->next != NULL)
                {
                    current->next->prev = prev; // Update the next node's previous pointer
                }
                delete current; // Delete the node
            }
            cout << "Node with data " << data << " deleted successfully." << endl;
        }
        else
        {
            cout << "Node with data " << data << " not found in the list." << endl;
        }
    }

    // Destructor to deallocate memory when the list object is destroyed
    ~list()
    {
        cout << "\n"
             << "List desctructor is called...."
             << "\n";
    }
};

int main()
{
    list l1; // Create an instance of the list class

    // Insert elements into the list
    l1.InsertAtEnd(22);
    l1.InsertAtEnd(23);
    l1.InsertAtEnd(24);
    l1.InsertAtEnd(25);

    // Display the list before deletion
    cout << "Before deletion:" << endl;
    l1.Reversedoubly(); // Display the list

    // Delete the node with data value 24 (assuming it exists)
    l1.deleteNode(24);

    // Display the list after deletion
    cout << "After deletion:" << endl;
    l1.Reversedoubly(); // Display the list

    return 0;
}
