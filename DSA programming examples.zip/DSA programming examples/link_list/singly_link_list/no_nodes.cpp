#include <iostream>
using namespace std;

class Node
{
    int data;
    Node *ptr;

public:
    Node(int data, Node *ptr)
    {
        this->data = data;
        this->ptr = ptr;
    }
    ~Node()
    {
        cout <<"\n"<< "Node destructor is called"
             << "\n";
    }
    friend class list;
};
class list
{
private:
    Node *head;

public:
    list()
    {
        head = NULL;
    }
    bool isEmpty()
    {
        return !head;
    }
    void InsertAtEnd(int data)
    {
        Node *new_node = new Node(data, NULL);
        Node *current = head;
        if (head == NULL)
        {
            head= new_node;
            new_node->ptr = NULL;
        }
        else
        {
            while (current->ptr != NULL)
            {
                current = current->ptr;
            }
            current->ptr = new_node;
            new_node->ptr = NULL;
        }
    }
    void traverse()
    {
        Node *curNode = head;
        int count=0;
        if (head == NULL)
        {
            cout << "list is empty"
                 << "\n";
        }
        else
        {
            while (curNode != NULL)
            {
                cout << curNode->data << "\t";
                curNode = curNode->ptr;
                count++;
            }
        }
        
        cout<<"\n"<<"Number of nodes in list are "<<count<<"\n";
    }
    ~list()
    {
        cout<<"\n" << "List desctructor is called...."
             << "\n";
    }
};

int main()
{

    list l1;
    l1.InsertAtEnd(22);
    l1.InsertAtEnd(23);
    l1.InsertAtEnd(24);
    l1.InsertAtEnd(25);
    l1.InsertAtEnd(26);
    l1.InsertAtEnd(27);
    l1.InsertAtEnd(28);
    l1.InsertAtEnd(29);
    l1.InsertAtEnd(2);
    l1.InsertAtEnd(3);
    l1.InsertAtEnd(42);
    l1.InsertAtEnd(62);
    l1.InsertAtEnd(72);
    l1.InsertAtEnd(82);
    l1.InsertAtEnd(92);
    l1.traverse();

    return 0;
}