#include<iostream>
using namespace std;

class Node
{
public:
    int data;
    Node *next;

    Node()
    {
        this->data = 0;
        this->next = NULL;
    }
    friend class list;
};

class list
{
private:
    Node *head;
public:
    list()
    {
        head = NULL;
    }
    bool isEmpty()
    {
        return (head == NULL);
    }
    void insertAtEnd(int data)
    {
        Node *newnode = new Node();
        newnode->data = data;
        newnode->next = NULL;

        if (head == NULL)
        {
            head = newnode;
        }
        else
        {
            Node *curNode = head;
            while (curNode->next != NULL)
            {
                curNode = curNode->next;
            }
            curNode->next = newnode;
        }
    }
    void traverseList()
    {
        cout << "traversing list:" << endl;
        if (head == NULL)
        {
            cout << "List is empty." << endl;
        }
        else
        {
            Node *curNode = head;
            while (curNode != NULL)
            {
                cout << curNode->data << " ";  // Add a space after each data
                curNode = curNode->next;
            }
            cout << endl;
        }
    }

                                //Reverse the list 
    void Reverselist()
    {
        Node* prev= new Node();
        Node* curNode=new Node();
        while(curNode->next!=NULL)
        {
            prev=curNode;
            curNode=curNode->next;
        }
        cout<<"Reversing the list"<<endl;
        while(prev!=NULL)
        {
        cout<<curNode->data<<endl;
        curNode=curNode->prev;
        prev=prev->prev;
        }
    }
};

int main()
{
    list l1;
    l1.insertAtEnd(2);
    l1.insertAtEnd(12);
    l1.insertAtEnd(22);
    l1.insertAtEnd(32);
    l1.insertAtEnd(42);
    l1.insertAtEnd(52);
    l1.insertAtEnd(62);
    l1.traverseList();

    return 0;
}
