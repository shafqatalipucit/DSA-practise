#include <iostream>
#include <string>
#include <cctype>
using namespace std;
bool ispalin(const string &s)
{
    int left = 0;
    int right = s.length() - 1;
    while (left < right)
    {
        if (s[left] != s[right])
        {
            return false;
        }
        left++;
        right--;
    }
    return true;
}
bool isdigi(char c)
{
    return isdigi(c);
}
int main()
{
    string a = "in12321.:[iopoi._6tyt6_:.qWsrGh+Z*+*z+HgH+Z_.AtErEtViiivTe";
    int maxlength = 0;
    string maxpalin;
    for (int i = 0; i < a.length(); i++)
    {
        for (int j = i; j < a.length(); j++)
        {
            string sub = a.substr(i, j - i + 1);
            if (ispalin(sub) && (sub.begin(), sub.end(), isdigi) && sub.length() > maxlength)
            {
                maxpalin = sub;
                maxlength = sub.length();
            }
        }
    }
    if(maxlength>0)
    {
        cout<<"lagest number is :"<<maxpalin<<endl;
    }
    else{
        cout<<"not found"<<endl;
    }

    return 0;
}