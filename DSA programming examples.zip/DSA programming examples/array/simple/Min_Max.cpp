#include<iostream>
using namespace std;

// Function to find the minimum element in an integer array
int Minimum(int A[], int size)
{
    int min = A[0]; // Initialize min with the first element of the array
    for(int i = 1; i < size; i++)
    {
        if(A[i] < min)
        {
            min = A[i]; // Update min if the current element is smaller
        }
    }
    return min; // Return the minimum value
}

// Function to find the maximum element in an integer array
int Maximum(int A[], int size)
{
    int max = A[0]; // Initialize max with the first element of the array
    for(int i = 1; i < size; i++)
    {
        if(A[i] > max)
        {
            max = A[i]; // Update max if the current element is larger
        }
    }
    return max; // Return the maximum value
}

int main()
{
    // Define an integer array
    int A[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 8, 7, 5, 4, 45, 5, 7, 8, 9, 8};
    
    // Calculate the size of the array
    int size = sizeof(A) / sizeof(A[0]);
    
    // Find the minimum element in the array
    int min = Minimum(A, size);
    
    // Find the maximum element in the array
    int max = Maximum(A, size);
    
    // Print the minimum and maximum elements
    cout << "Minimum element is: " << min << "\n";
    cout << "Maximum element is: " << max << "\n";

    return 0;
}
