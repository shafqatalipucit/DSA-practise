#include <istream>
#include <vector>
#include <deque>
using namespace std;
vector<int> fun1(const vector<int> a, int k)
{
    vector<int> res;
    vector<int> wind;
    for (int i = 0; i < a.size(); i++)
    {
        if (!wind.empty() && wind.front() == i - k)
        {
            int b = wind.front();

            while (!wind.empty() && a[i] >= a[wind.back()])
            {
                wind.pop_back();
            }
        }
        wind.pop_back();
        if (i >= k - 1)
        {
            res.push_back(a[wind.front()]);
        }
    }
    return res;
}

int main()
{
    vector<int> num = {1, 2, 3, 4, 5, 4, 3, 2, 1, 2, 4, 54, 0};
    int k = 3;
    vector<int> result = fun1(num, k);
    for( int i=0;i<num.size();i++)
    {
        cout<<num;
    }
    return 0;
}