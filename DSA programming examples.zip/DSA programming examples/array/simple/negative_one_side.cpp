#include <iostream>
using namespace std;

// Function to swap two integers
void swap(int &a, int &b)
{
    int temp = a; // Store the value of 'a' in a temporary variable
    a = b;        // Assign the value of 'b' to 'a'
    b = temp;     // Assign the value of the temporary variable to 'b'
}

// Function to rearrange the elements of an integer array such that negative numbers appear before positive numbers
void Negative_One_Side(int *A, int size)
{
    int i = 0, j = size - 1; // Initialize two pointers 'i' and 'j' at the start and end of the array, respectively
    while (i < j) // Loop until 'i' crosses 'j'
    {
        if (A[i] > 0 && A[j] <= 0) // If 'A[i]' is positive and 'A[j]' is negative, swap them
        {
            swap(A[i], A[j]); // Swap the elements
            i++, j--;         // Move 'i' to the right and 'j' to the left
        }
        else if (A[i] < 0) // If 'A[i]' is already negative, move 'i' to the right
        {
            i++;
        }
        else if (A[j] > 0) // If 'A[j]' is already positive, move 'j' to the left
        {
            j--;
        }
        else // If neither condition is met, the array is already in the desired shape
        {
            cout << "Already in the desired shape" << "\n";
            return; // Exit the function
        }
    }
    
    // Print the rearranged array
    cout << "Desired array is" << "\n";
    for (int i = 0; i < size; i++)
    {
        cout << A[i] << "\t";
    }
    cout << "\n";
}

int main()
{
    int A[] = {-2, -3, 2, 3, 5, 6, 4, 5, 4, 0, -1, -4, -8}; // Define an integer array
    int size = sizeof(A) / sizeof(A[0]); // Calculate the size of the array
    Negative_One_Side(A, size); // Rearrange the array
    return 0;
}
