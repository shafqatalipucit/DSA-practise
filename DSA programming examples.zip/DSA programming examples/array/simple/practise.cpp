#include <iostream>
using namespace std;


string remove(string a,int size)

{
    
    string b[size];
    
    for(int i=0;i<size;i++)
    {
        
            if(a[i] ==' ' )
            {
                continue;

            }
            else{
                b[i]==a[i];
            }
    }
   
}

int main()
{
 string a="hellow world  ";
 int size=sizeof(a)/sizeof(char);
 string c=remove(a,size);
 cout<<c;
}
