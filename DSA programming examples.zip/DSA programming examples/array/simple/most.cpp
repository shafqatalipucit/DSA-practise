#include <iostream>
using namespace std;
int frequent(int A[], int size)
{
    int count, max;
    for (int i = 0; i < size; i++)
    {

        int maxcount = 1;

        for (int j = i + 1; j < size; j++)
        {
            if (A[i] == A[j])
            {
                count++;
            }
            if (count > maxcount)
            {
                max = A[i];
            }
        }
    }
    return max;
}
int main()
{
    int a[] = {1, 2, 3, 4, 4, 4, 4, 4};
    int size = sizeof(a) / sizeof(a[0]);
    int max = frequent(a, size);

    cout << max;
    return 0;
}