#include<iostream>
using namespace std;

// Function to swap two integers
void swap(int& a, int& b)
{
    int temp = a; // Store the value of 'a' in a temporary variable
    a = b;        // Assign the value of 'b' to 'a'
    b = temp;     // Assign the value of the temporary variable to 'b'
}

// Function to sort an array of integers in ascending order
void sortArray(int *A,int size)
{
    for(int i = 0; i < size; i++)
    {
        for(int j = 1; j < size - i; j++)
        {
            if(A[j - 1] >=A[j])
            {
                swap(A[j - 1], A[j]); // Swap the elements if they are in the wrong order
                
            }
        }
    }

    // Print the sorted array
    for(int i = 0; i < size; i++)
    { 
        cout << A[i] << "\t";
    }
}

int main()
{
    int A[] = {2,1,2,1,0,0,0}; // Define an integer array
    int size = sizeof(A) / sizeof(A[0]); // Calculate the size of the array
    sortArray(A, size); // Sort the array
    return 0;
}
