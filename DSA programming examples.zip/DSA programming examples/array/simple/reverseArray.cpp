#include<iostream>
using namespace std;

// Function to reverse the elements of an integer array and print them
void ReverseString(int A[], int size)
{
    // Loop through the array in reverse order
    for(int j = size - 1; j >= 0; j--)
    {
        // Print the element at index j
        cout << A[j] << "\t";
    }
}

int main()
{
    // Define an integer array
    int A[] = {1, 2, 3, 4, 5, 6, 7, 8, 9};
    
    // Calculate the size of the array
    int size = sizeof(A) / sizeof(A[0]);
    
    // Call the function to reverse the array and print it
    ReverseString(A, size);
    
    return 0;
}
