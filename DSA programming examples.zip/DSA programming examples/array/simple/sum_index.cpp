#include <iostream>
using namespace std;

// Function to find the indices of the subarray whose elements sum up to the given key
void SumOfIndex(int *A, int size, int key)
{
    // Iterate through each element of the array as a potential starting point of the subarray
    for (int i = 0; i < size; i++)
    {
        int sum = 0; // Initialize the sum of the subarray to 0

        // Iterate through the elements starting from the current index 'i'
        for (int j = i; j < size; j++)
        {
            sum += A[j]; // Add the current element to the sum

            // If the sum equals the given key, print the indices and return
            if (sum == key)
            {
                cout << "The given number is the sum between indices: " << i << " and " << j << "\n";
                return;
            }
        }
    }

    // If no subarray with the given sum is found
    cout << "Subarray with the given sum not found\n";
}

// Main function to test the SumOfIndex function
int main()
{
    int A[] = {2, 3, 4, 3, 2, 1, 2, 3, 4};
    int size = sizeof(A) / sizeof(A[0]);
    int key = 6;
    SumOfIndex(A, size, key); // Call the function to find the subarray indices
    return 0;
}
