#include <iostream>
using namespace std;

// Function to count occurrences of a key in an integer array
int occurrenceInt(int A[], int size, int key)
{
    int count = 0; // Initialize a counter to store the number of occurrences

    // Loop through the array elements
    for (int i = 0; i < size; i++)
    {
        if (A[i] == key) // Check if the current element matches the key
        {
            count++; // Increment the counter if the element matches the key
        }
    }

    return count; // Return the total count of occurrences
}

int main()
{
    int A[] = {1, 2, 3, 4, 5, 7, 8, 7, 5, 4, 3, 4, 5, 7, 8, 5, 4, 5, 6, 7, 6}; // Define an integer array
    int size = sizeof(A) / sizeof(A[0]); // Calculate the size of the array
    int occurrence = occurrenceInt(A, size, 5); // Call the function to count occurrences of '5' in the array
    cout << "Element occurs " << occurrence << " times in the array." << endl; // Print the result
    return 0;
}
