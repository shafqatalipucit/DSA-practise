#include <iostream>
using namespace std;

// Function to find the peak element in an integer array
int peakArray(int A[], int size)
{
    int peak = 0; // Initialize peak element to 0

    if (size < 2)
    {
        return 0; // Return 0 if array size is less than 2 (no peak possible)
    }
    else
    {
        for (int i = 0; i < size; i++)
        {
            // Check if the current element is greater than its neighbors
            if ((A[i] > A[i - 1]) && (A[i] > A[i + 1]))
            {
                peak = A[i]; // Update peak element if condition is met
            }
        }
    }
    return peak; // Return the peak element
}

int main()
{
    int A[] = {1, 2, 4, 3, 4, 2, 4, 5, 6, 4, 3, 3}; // Define an integer array
    int size = sizeof(A) / sizeof(A[0]); // Calculate the size of the array
    int peak = peakArray(A, size); // Find the peak element in the array
    cout << "Peak is: " << peak << "\n"; // Print the peak element
    return 0; // Return 0 to indicate successful termination
}
