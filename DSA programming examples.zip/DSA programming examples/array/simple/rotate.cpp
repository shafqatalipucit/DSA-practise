#include<iostream>
using namespace std;
void rotate(int A[] ,int size,int k)
{
    int b[size];
    for(int i=0;i<k;i++)
    {
        int temp=A[size-1];
    

        for(int j=size-1;j>0;j--)
        {
            b[j]=A[j-1];
        }
        b[0]=temp;
    }
    for(int i=0;i<size;i++)
    {
        cout<<b[i]<<" ";
    }
}
int main()
{
    int a[]={1,2,3,4};
    int size=sizeof(a)/sizeof(a[0]);
    rotate(a,size,1);
    
    return 0;
}