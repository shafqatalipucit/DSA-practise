#include <iostream>
using namespace std;

// Function to find the intersection of two arrays
void intersection(int *A, int sizeA, int *B, int sizeB) {
    // Allocate memory for the intersection array
    // The maximum possible size of the intersection array is the minimum of the two input array sizes
    int *arr = new int[min(sizeA, sizeB)]; 
    int k = 0; // Index for the intersection array

    // Nested loops to compare elements of both arrays
    for (int i = 0; i < sizeA; i++) {
        for (int j = 0; j < sizeB; j++) {
            if (A[i] == B[j]) { // If there's a match, add it to the intersection array
                arr[k++] = A[i];
                break; // Move to the next element in A
            }
        }
    }

    // Display the intersection array
    cout << "Intersection is:\n";
    for (int i = 0; i < k; i++) {
        cout << arr[i] << " ";
    }

    // Deallocate memory
    delete[] arr;
}

// Function to find the union of two arrays
void unionArray(int *A, int sizeA, int *B, int sizeB) {
    int size = sizeA + sizeB;
    int *arr = new int[size]; // Allocate memory for the union array
    int i = 0, j = 0, k = 0;

    // Merge the two arrays into the union array
    while (i < sizeA && j < sizeB) {
        if (A[i] < B[j]) {
            arr[k] = A[i++];
        } else if (A[i] > B[j]) {
            arr[k] = B[j++];
        } else { // If both elements are equal, add one to the union array
            arr[k] = A[i++];
            j++; // Move both pointers to skip duplicates
        }
        k++;
    }

    // Add remaining elements from A, if any
    while (i < sizeA) {
        arr[k++] = A[i++];
    }
    // Add remaining elements from B, if any
    while (j < sizeB) {
        arr[k++] = B[j++];
    }

    // Display the union array
    cout << "Union is :\n";
    for (int i = 0; i < k; i++) {
        cout << arr[i] << " ";
    }

    // Deallocate memory
    delete[] arr;
}

// Main function
int main() {
    int A[] = {1, 2, 3, 4, 5, 6, 7, 8, 9};
    int B[] = {3, 4, 5, 6, 7, 8, 9, 10, 11};
    int sizeA = sizeof(A) / sizeof(A[0]);
    int sizeB = sizeof(B) / sizeof(B[0]);

    // Find and display the union of the two arrays
    unionArray(A, sizeA, B, sizeB);
    // Find and display the intersection of the two arrays
    intersection(A, sizeA, B, sizeB);

    return 0;
}
