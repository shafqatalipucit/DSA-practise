#include <iostream>
using namespace std;

// Function to find the first duplicate element in the array A
int duplicate(int *A, int sizeA) {
    // Loop through each element of the array
    for(int i = 0; i < sizeA; i++) {
        // Nested loop to compare the current element with the rest of the elements
        for(int j = i + 1; j < sizeA; j++) {
            // If a duplicate is found, return the duplicate element
            if(A[i] == A[j]) {
                return A[i];
            }
        }
    }
    // If no duplicate is found, return -1
    return -1;
}

int main() {
    // Input array and its size
    int A[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 1, 2};
    int sizeA = sizeof(A) / sizeof(A[0]);

    // Call the duplicate function to find the first duplicate element
    int repeating = duplicate(A, sizeA);

    // Output the result
    if(repeating != -1) {
        cout << "First duplicate element: " << repeating << endl;
    } else {
        cout << "No duplicate element found." << endl;
    }

    return 0;
}
