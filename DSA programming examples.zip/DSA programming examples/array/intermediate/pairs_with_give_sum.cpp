#include <iostream>
using namespace std;

// Function to count pairs in the array whose sum equals a given key
int paircount(int *A, int size, int key) {
    int count = 0; // Initialize a counter to keep track of the number of pairs

    // Loop through each element of the array
    for (int i = 0; i < size; i++) {
        // For each element A[i], loop through elements after it (to the right)
        for (int j = i + 1; j < size; j++) {
            // If the sum of A[i] and A[j] equals the given key, increment the counter
            if (A[i] + A[j] == key) {
                count++;
            }
        }
    }

    // Return the count of pairs whose sum equals the key
    return count;
}

int main() {
    int A[] = {1, 2, 3, 4, 5, 6, 7, 8, 9};
    int sizeA = sizeof(A) / sizeof(A[0]); // Calculate the size of the array

    // Call the paircount function to count pairs whose sum equals 6
    int count = paircount(A, sizeA, 6);

    // Display the count of pairs
    cout << "Number of pairs whose sum equals 6: " << count << endl;

    return 0;
}
