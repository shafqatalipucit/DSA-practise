#include <iostream>
using namespace std;

int nonDuplicate(int *A, int sizeA) {
    bool repeating;
    for (int i = 0; i < sizeA; i++) {
        repeating = false; // Reset the flag for each iteration of the outer loop
        for (int j = 0; j < sizeA; j++) {
            if (A[i] == A[j] && i != j) {
                repeating = true; // Mark as repeating if a duplicate is found
                break;
            }
        }
        if (!repeating) { // If no duplicate found for A[i], return it
            return A[i];
        }
    }
    return -1; // If no unique element found, return -1
}

int main() {
    int A[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 1, 2};
    int sizeA = sizeof(A) / sizeof(A[0]);

    int unique = nonDuplicate(A, sizeA);

    if (unique != -1) {
        cout << "First unique element: " << unique << endl;
    } else {
        cout << "No unique element found." << endl;
    }

    return 0;
}
