#include <iostream>
using namespace std;

// Function to find the length of the longest consecutive subsequence
void longest_subsequence(int *A, int size)
{
    int count = 1, larger = 0; // Initialize count and larger
    for (int i = 0; i < size; i++) // Iterate through the array
    {
        if (A[i + 1] - A[i] == 1) // If the next element is consecutive
        {
            count++; // Increment the count
        }
        else // If not consecutive
        {
            count = 1; // Reset the count
        }
        
        if (count > larger) // Update larger if count is greater
        {
            larger = count;
        }
    }
    
    // Output the result
    cout << "Count of number of elements in consecutive array is: " << larger << "\n";
}

int main()
{
    int A[] = {1, 2, 3, 5, 6, 7, 8, 9, 10};
    int size = sizeof(A) / sizeof(A[0]);
    longest_subsequence(A, size);
    return 0;
}
