#include<iostream>
using namespace std;

// Function to check if any subarray has sum equal to zero
bool subarray_sum(int *A, int size) {
    int sum = 0;
    for (int i = 0; i < size; i++) {   
        sum = A[i]; // Initialize sum with current element
        if (sum == 0) {
            return true; // If current element is zero, return true
        }
        for (int j = 1; j < size; j++) { // Iterate through remaining elements
            sum = sum + A[j]; // Add next element to sum
            if (sum == 0) {
                return true; // If sum becomes zero, return true
            }
        }
    }
}

int main() {
    int A[] = {1, 2, 3, 4, 5, 6, 5, 4, 3, -2, -3};
    int size = sizeof(A) / sizeof(A[0]);
    bool flag = subarray_sum(A, size); // Call the function to check subarray sum
    cout << flag; // Output the result
    return 0;
}
