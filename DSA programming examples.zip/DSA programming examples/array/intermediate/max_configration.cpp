#include <iostream>
using namespace std;

// Function to find the maximum of two numbers
int maximum(int a, int b)
{
    int max;
    if (a > b)
    {
        max = a;
    }
    else
    {
        max = b;
    }
    return max;
}

// Function to find the maximum configuration of an array
int max_configuration(int *A, int size)
{
    int sum = 0, max = 0, result = 0;
    for (int i = 0; i < size; i++) // Iterate through all possible starting positions
    {
        int sum = 0; // Reset sum for each starting position
        for (int j = 0; j < size; j++) // Iterate through all elements of the array
        {
            int index = (i + j) % size; // Compute the index considering circular array
            sum += A[index] * j; // Calculate the sum based on the formula
        }
        result = maximum(sum, result); // Update the result with the maximum sum found
    }
    return result; // Return the maximum configuration
}

int main()
{
    int A[] = {-4, 2, 3, 5, 6, 7, 8, 9, -10};
    int size = sizeof(A) / sizeof(A[0]); // Calculate the size of the array
    int result = max_configuration(A, size); // Call the function to find the maximum configuration
    cout << "Max configuration is: " << result << "\n"; // Print the result
    return 0;
}
