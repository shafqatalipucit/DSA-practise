#include <iostream>
#include <chrono>

int Number(tm *A, int sizeA, int start, int end)
{
    int count = 0;
    for (int i = start; i < end; i++)
    {
        if ((A[i + 1].tm_hour - A[i].tm_hour) > 0)
        {
            count++;
        }
    }
    return count;
}

int main()
{
    tm specific_time[12] = {};
    specific_time[0] = {0, 0, 9, 1, 0, 0};
    specific_time[1] = {0, 0, 10, 1, 0, 0};
    specific_time[2] = {0, 0, 11, 1, 0, 0};
    specific_time[3] = {0, 0, 12, 1, 0, 0};
    specific_time[4] = {0, 0, 13, 1, 0, 0};
    specific_time[5] = {0, 0, 14, 1, 0, 0};
    specific_time[6] = {0, 0, 9, 1, 0, 0};
    specific_time[7] = {0, 0, 9, 1, 0, 0};
    specific_time[8] = {0, 0, 9, 1, 0, 0};
    specific_time[9] = {0, 0, 9, 1, 0, 0}; // 09:00 AM
    int size = sizeof(specific_time) / sizeof(specific_time[0]); // Calculate the size of the array
    int count = Number(specific_time, size, 3, 9); // Counting from index 3 to 9
    std::cout << "Count of intervals with positive difference: " << count << std::endl;
    return 0;
}
