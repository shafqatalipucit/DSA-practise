#include <iostream>
using namespace std;

void lagrest_sum_contigious(int *A, int size)
{
    int maxsofar = A[0]; // Initialize with the first element
    int maximum = A[0]; // Initialize with the first element
    int start = 0, end = 0;

    for (int i = 1; i < size; i++) // Start from index 1
    {
        if (A[i] > maximum + A[i]) // If A[i] is greater than the sum so far, start a new subarray
        {
            maximum = A[i];
            start = i;
        }
        else
        {
            maximum = maximum + A[i]; // Extend the current subarray
        }

        if (maximum > maxsofar) // Update maxsofar and end whenever a new maximum sum is found
        {
            maxsofar = maximum;
            end = i;
        }
    }

    cout << "Subarray with the largest sum: ";
    for (int k = start; k <= end; k++)
    {
        cout << A[k] << "\t";
    }
}

int main()
{
    int A[] = {1, 2, 3, 4, 45, 6, 7, 8, -1, -4, -6};
    int size = sizeof(A) / sizeof(A[0]);
    lagrest_sum_contigious(A, size);

    return 0;
}
