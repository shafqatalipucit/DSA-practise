#include <iostream>
using namespace std;

void duplicate(int *A, int size)
{
    int max1, max2, max3;
    max1 = A[0];
    max2 = A[0];
    max3 = A[0];
    for (int i = 1; i < size; i++)
    {
        if (A[i] > max1)
        {
            max3 = max2;
            max2 = max1;
            max1 = A[i];
        }
    }
    cout << max1 << "\n";
    cout << max2 << "\n";
    cout << max3 << "\\n";
}

int main()
{
    int A[] = {1, 2, 3, 4, 5, 6, 5, 4, 3, 2};
    int size = sizeof(A) / sizeof(A[0]);
    duplicate(A, size);
    return 0;
}
