#include <iostream>
using namespace std;

// Function to find the minimum element in an array
int Minimum(int *A, int size)
{
    int min = A[0]; // Initialize min with the first element
    for (int i = 0; i < size; i++) // Iterate through the array
    {
        if (min > A[i]) // If the current element is smaller than min
        {
            min = A[i]; // Update min with the current element
        }
    }
    return min; // Return the minimum element
}

int main()
{
    int A[] = {-4, 2, 3, 5, 6, 7, 8, 9, -10};
    int size = sizeof(A) / sizeof(A[0]); // Calculate the size of the array
    int min = Minimum(A, size); // Call the Minimum function to find the minimum element
    cout << "Minimum element is: " << min; // Print the minimum element
    return 0;
}
