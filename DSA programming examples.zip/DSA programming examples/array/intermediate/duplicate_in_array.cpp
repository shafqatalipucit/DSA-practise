#include <iostream>
using namespace std;

// Function to count the number of duplicate elements in the array
int duplicate(int *A, int size) {
    int count = 0; // Initialize a counter to keep track of the number of duplicates

    // Loop through each element of the array
    for (int i = 0; i < size; i++) {
        // For each element A[i], loop through elements after it (to the right)
        for (int j = i + 1; j < size; j++) {
            // If the current element A[i] is equal to any element A[j] to its right, increment the counter
            if (A[i] == A[j])  {
                count++;
                // Using 'continue' here to skip to the next iteration of the inner loop
                // This is because if A[i] is found to be equal to A[j], we only count it once
                // and move on to the next element in the outer loop
                continue;
            }
        }
    }

    // Return the count of duplicate elements
    return count;
}

int main() {
    int A[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 1};
    int sizeA = sizeof(A) / sizeof(A[0]); // Calculate the size of the array

    // Call the duplicate function to count duplicate elements in the array
    int count = duplicate(A, sizeA);

    // Display the count of duplicate elements
    cout << "Number of duplicate elements: " << count << endl;

    return 0;
}
