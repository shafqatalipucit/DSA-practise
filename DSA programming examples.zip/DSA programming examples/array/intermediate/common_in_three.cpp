#include <iostream>
using namespace std;

// Function to count the number of duplicate elements in the arrays A, B, and C
int duplicate(int *A, int sizeA, int *B, int sizeB, int *C, int sizeC) {
    int count = 0; // Initialize a counter to keep track of the number of duplicates

    // Loop through array A from index 0 to sizeA - 1
    for (int i = 0; i < sizeA - 1; i++) {
        // Check if the current element A[i] is the same as the next element A[i + 1]
        if (A[i] == A[i + 1]) {
            continue; // Skip if a duplicate is found
        }

        // Loop through array B from index 0 to sizeB - 1
        for (int j = 0; j < sizeB - 1; j++) {
            // Check if the current element B[j] is the same as the next element B[j + 1]
            if (B[j] == B[j + 1]) {
                continue; // Skip if a duplicate is found
            }

            // Compare elements of A and B
            if (A[i] == B[j]) {
                // Loop through array C from index 0 to sizeC - 1
                for (int k = 0; k < sizeC - 1; k++) {
                    // Check if the current element C[k] is the same as the next element C[k + 1]
                    if (C[k] == C[k + 1]) {
                        continue; // Skip if a duplicate is found
                    }
                    
                    // If A[i] is equal to any element in array C, increment the count
                    if (A[i] == C[k]) {
                        count++;
                    }
                }
            }
        }
    }

    // Return the count of duplicate elements
    return count;
}

int main() {
    int A[] = {1, 2, 3, 4, 5, 6, 7, 8, 9};
    int sizeA = sizeof(A) / sizeof(A[0]);

    int B[] = {0, 0, 0, 1, 2, 3};
    int sizeB = sizeof(B) / sizeof(B[0]);

    int C[] = {1, 2, 3, 4, 5, 6, 7, 8, 9};
    int sizeC = sizeof(C) / sizeof(C[0]);

    // Call the duplicate function to count duplicate elements in the arrays A, B, and C
    int count = duplicate(A, sizeA, B, sizeB, C, sizeC);

    // Display the count of duplicate elements
    cout << "Number of duplicate elements: " << count << endl;

    return 0;
}
