#include <iostream>
using namespace std;

// Function to rotate the array elements by one position to the left
void RotateByOne(int A[], int size) {
    // Allocate memory for a new array B to hold the rotated elements
    int *B = new int[size];

    // Copy elements from A to B with a one-position left shift
    for (int i = 1; i < size; i++) {
        B[i] = A[i - 1];
    }
    
    // Move the last element of A to the first position of B
    B[0] = A[size - 1];

    // Display the rotated array
    for (int i = 0; i < size; i++) {
        cout << B[i] << " ";
    }

    // Deallocate memory used for array B
    delete[] B;
}

int main() {
    int A[] = {1, 2, 3, 4, 5, 6, 7, 8, 9};
    int sizeA = sizeof(A) / sizeof(A[0]);

    // Rotate the array A by one position to the left and display the result
    RotateByOne(A, sizeA);

    return 0;
}
