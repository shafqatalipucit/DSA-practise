#include <iostream>
using namespace std;

long  factorial(int larger)
{
    if(larger<0)
    {
        cout<<"not possible"<<"\n";
    }
    if (larger == 1 || larger == 0)
    {
        return 1;
    }
    else
    {

        return (larger * factorial(larger - 1));
    }
}
void factiorialLargerNumber(int *A, int size)
{
    int larger = A[0];
    for (int i = 1; i < size; i++)
    {
        if (larger < A[i])
        {
            larger = A[i];
        }
    }

    cout << "Larger number is :" << larger << "\n";
     long fac = factorial(larger);
    cout << "Factorial of  number is:" << fac << "\n";
}

int main()
{
    int A[] = {1, 2, 3, 4, 0, 6, 7, 8, -1, -4, -6};
    int size = sizeof(A) / sizeof(A[0]);
    factiorialLargerNumber(A, size);
    return 0;
}
