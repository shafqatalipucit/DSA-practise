#include <iostream>
using namespace std;

// Function to find the element with the minimum frequency in an array
int min_frequent_element(int *A, int size)
{
    int min_freq = size + 1; // Initialize the minimum frequency to a value greater than the array size
    int min_element = -1; // Initialize the minimum frequent element to -1 (indicating no element found)
    
    // Iterate through each element in the array
    for (int i = 0; i < size; i++)
    {
        int count = 1; // Initialize the count for the current element
        
        // Count the frequency of the current element by comparing with subsequent elements
        for (int j = i + 1; j < size; j++)
        {
            if (A[i] == A[j])
            {
                count++; // Increment count for each occurrence of the current element
            }
        }
        
        // Check if the frequency of the current element is less than the minimum frequency found so far
        if (count < min_freq)
        {
            min_freq = count; // Update the minimum frequency
            min_element = A[i]; // Update the minimum frequent element
        }
    }
    
    return min_element; // Return the minimum frequent element found
}

int main()
{
    int A[] = {5, 5, 5, 5, 5, 1, 2, 3, 2, 1}; // Example array
    int size = sizeof(A) / sizeof(A[0]); // Calculate the size of the array

    // Call the function to find the element with the minimum frequency
    int min_element = min_frequent_element(A, size);
    
    // Output the element with the minimum frequency
    if (min_element != -1)
    {
        cout << "Element with minimum frequency: " << min_element << "\n";
    }
    else
    {
        cout << "No element found in the array.\n";
    }

    return 0;
}
