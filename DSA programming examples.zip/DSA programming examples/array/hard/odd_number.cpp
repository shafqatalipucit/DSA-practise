#include <iostream>
using namespace std;

// Function to find the number that occurs an odd number of times in the array
int odd_occurrence(int *A, int size)
{
    int odd_element = 0;
    for (int i = 0; i < size; i++)
    {
        int count = 0;
        for (int j = 0; j < size; j++)
        {
            if (A[i] == A[j])
            {
                count++;
            }
        }
        if (count % 2 != 0)
        {
            odd_element = A[i];
            break; // If we found an element with odd occurrences, no need to continue
        }
    }
    return odd_element;
}

int main()
{
    int A[] = {5, 5, 5, 5, 5, 5, 2, 3, 2, 1}; // Example array
    int size = sizeof(A) / sizeof(A[0]);      // Calculate the size of the array

    // Call the odd_occurrence function to find the element with odd occurrences
    int result = odd_occurrence(A, size);

    // Output the result
    if (result == 0)
    {
        cout << "No element occurs an odd number of times" << endl;
    }
    else
    {
        cout << "Number that occurs an odd number of times: " << result << endl;
    }

    return 0;
}
