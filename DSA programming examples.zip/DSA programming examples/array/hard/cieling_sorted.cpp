#include <iostream>
using namespace std;

// Function to find the number that occurs an odd number of times in the array
void leader_array(int *A, int sizeA)
{
    int *AA = new int[sizeA];
    for (int i = 0; i < sizeA; i++)
    {
        if ((A[i] <= A[i + 1]) && (i != sizeA - 1))
        {
            AA[i] = A[i];
            
        }
        if (i == sizeA - 1)
        {
            AA[i] = A[sizeA - 1];
        }
    }

    int sizeAA = sizeof(AA) / sizeof(AA[0]); // Calculate the size of the array
    cout << "Leading element are :"
         << "\n";
    for (int i = 0; i < sizeAA; i++)
    {
        cout << AA[i] << "\t";
    }
}

int main()
{
    int A[] = {1, 2, 3, 4, 5, 6, 7};      // Example array
    int sizeA = sizeof(A) / sizeof(A[0]); // Calculate the size of the array

    leader_array(A, sizeA);

    return 0;
}
