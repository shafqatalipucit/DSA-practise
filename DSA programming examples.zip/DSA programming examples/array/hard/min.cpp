#include <iostream>
using namespace std;

// Function to find the minimum element in an array
int findMin(int *A, int size)
{
    int min = A[0]; // Initialize min to the first element of the array
    // Iterate through the array to find the minimum element
    for (int i = 1; i < size; i++)
    {
        // Update min if the current element is smaller than the current minimum
        if (min > A[i])
        {
            min = A[i];
        }
    }
    return min; // Return the minimum element
}

int main()
{
    int A[] = {1, 2, 3, 4, 5, 5, -2};
    int size = sizeof(A) / sizeof(A[0]); // Calculate the size of the array

    // Call the function to find the minimum element in the array
    int found = findMin(A, size);
    
    // Output the minimum element found
    cout << "Minimum element is: " << found << "\n";

    return 0;
}
