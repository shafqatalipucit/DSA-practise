#include <iostream>
using namespace std;

// Function to find the fixed point in the array
int fixed_point(int *A, int size) {
    for (int i = 0; i < size; i++) {
        // If the current element is equal to its index, return the element
        if (A[i] == i) {
            return A[i];
        }
    }
    // If no fixed point is found, return -1
    return -1;
}

int main() {
    int A[] = {5, 5, 5, 5, 5, 5, 2, 3, 2, 1}; // Example array
    int size = sizeof(A) / sizeof(A[0]); // Calculate the size of the array

    // Call the fixed_point function to find the fixed point
    int result = fixed_point(A, size);

    // Output the result
    if (result == -1) {
        cout << "Fixed point not found" << endl;
    } else {
        cout << "Fixed point found: " << result << endl;
    }

    return 0;
}
