#include <iostream>
using namespace std;

// Function to find the number that occurs an odd number of times in the array
void Missing_Element(int *A, int sizeA, int *B, int sizeB)
{
    for (int i = 0; i < sizeA; i++)
    {
        if (A[i] != B[i])
        {
            cout << "the Element is lost:" <<"\t"<< A[i] << "\n";
        }
    }
}

int main()
{
    int A[] = {3, 2, 1};                  // Example array
    int sizeA = sizeof(A) / sizeof(A[0]); // Calculate the size of the array

    int B[] = {3, 2};                     // Example array
    int sizeB = sizeof(B) / sizeof(B[0]); // Calculate the size of the array
    Missing_Element(A, sizeA, B, sizeB);

    return 0;
}
