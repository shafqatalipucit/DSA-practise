#include <iostream>
using namespace std;

// Function to find the last duplicate element in an array
int last_duplicate(int *A, int size)
{
    int duplicate = 0; // Initialize the variable to store the last duplicate element
    for (int i = 0; i < size; i++)
    {
        for (int j = i + 1; j < size; j++)
        {
            // Check if the current element is equal to any subsequent element
            if (A[i] == A[j])
            {
                duplicate = A[i]; // Update the duplicate variable with the current duplicate element
                // Continue searching for duplicates
            }
        }
    }
    return duplicate; // Return the last duplicate element found
}

int main()
{
    int A[] = {1, 2, 3, 1, 2, 3, 1, 2, 3, 4, 1, 2, 3, 4};
    int size = sizeof(A) / sizeof(A[0]); // Calculate the size of the array

    // Call the function to find the last duplicate element in the array
    int found = last_duplicate(A, size);
    
    // Output the last duplicate element found
    cout << "Last duplicate element is: " << found << "\n";

    return 0;
}
