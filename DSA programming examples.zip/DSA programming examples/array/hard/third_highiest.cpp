#include <iostream>
using namespace std;

// Function to find the number that occurs an odd number of times in the array
void third_highiest(int *A, int sizeA)
{
    int max1 = 0, max2 = 0, max3 = 0;
    for (int i = 0; i < sizeA; i++)
    {
        if (max1 < A[i])
        {
            max3 = max2;
            max2 = max1;
            max1 = A[i];
        }
    }
    cout<<"The 3rd maximum value is:"<<"\t"<<max3<<"\n";
}

int main()
{
    int A[] = {1,2,3,4,5,6,7};                  // Example array
    int sizeA = sizeof(A) / sizeof(A[0]); // Calculate the size of the array

    third_highiest(A,sizeA);

    return 0;
}
