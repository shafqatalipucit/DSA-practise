#include <iostream>
using namespace std;

// Function to find the most frequent element in an array
int most_frequent(int *A, int size)
{
    int max = 0; // Initialize the variable to store the maximum frequency
    int element=A[0];
    int count = 0; // Initialize the variable to count the frequency of each element
    for (int i = 0; i < size; i++)
    {
        count = 1; // Reset count to 1 for each element in the array
        for (int j = i + 1; j < size; j++)
        {
            // Check if the current element is equal to any subsequent element
            if (A[i] == A[j])
            {
                count++; // Increment the count for each occurrence of the current element
            }
        }
        // Check if the frequency of the current element is greater than the maximum frequency found so far
        if (max < count)
        {
            max = count; // Update the maximum frequency
            element=A[i];
        }
    }
    return element; // Return the maximum frequency found
}

int main()
{
    int A[] = {1, 2, 3, 5, 5}; // Example array
    int size = sizeof(A) / sizeof(A[0]); // Calculate the size of the array

    // Call the function to find the most frequent element in the array
    int found = most_frequent(A, size);
    
    // Output the maximum frequency found
    cout << "Maximum frequency is: " << found << "\n";

    return 0;
}
