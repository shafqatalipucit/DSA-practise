#include <iostream>
using namespace std;

// Function to find the element that appears only once in the array
int appear_once(int *A, int size)
{
    for (int i = 0; i < size; i++)
    {
        bool found = false; // Initialize a flag to track if the element is found elsewhere
        for (int j = 0; j < size; j++)
        {
            if (i != j && A[i] == A[j]) // Check if the element appears elsewhere in the array
            {
                found = true; // Set the flag if the element is found elsewhere
                break; // No need to check further
            }
        }
        if (!found) // If the element is not found elsewhere, it appears only once
        {
            return A[i]; // Return the element that appears only once
        }
    }
    // If no element appears only once, return -1 or any appropriate value indicating no such element
    return -1;
}

int main()
{
    int A[] = {5, 5, 5, 5, 5, 5, 2, 3, 2, 1}; // Example array
    int size = sizeof(A) / sizeof(A[0]);      // Calculate the size of the array

    // Call the appear_once function to find the element that appears once
    int result = appear_once(A, size);

    // Output the result
    cout << "Element that appears once: " << result << endl;

    return 0;
}
