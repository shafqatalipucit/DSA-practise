#include <iostream>
using namespace std;

// Function to find subarrays with a given sum
void sum_subarray(int *A, int size, int key)
{
    int sum = 0;
    int start = 0, end = 0;
    // Iterate through the array elements
    for (int i = 0; i < size; i++)
    {
        bool flag = false;
        sum = A[i];
        start = i;
        // Iterate through the remaining elements to find subarrays
        for (int j = i + 1; j < size; j++)
        {
            sum = sum + A[j];
            // If sum matches the given key, print the subarray
            if (sum == key)
            {
                cout << "Found" << "\n";
                flag = true;
                end = j;
                cout << "Required subarray is :" << "\n";
                // Print the subarray elements
                for (int k = start; k <= end; k++)
                {
                    cout << A[k] << "\t";
                }
            }
        }
    }
}

int main()
{
    int A[] = {1, 2, 3, 4, 5, 5};
    int size = sizeof(A) / sizeof(A[0]); // Calculate the size of the array
    sum_subarray(A, size, 6); // Call the function to find subarrays with sum 6
    return 0;
}
