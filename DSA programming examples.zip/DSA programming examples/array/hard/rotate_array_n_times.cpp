#include <iostream>
using namespace std;

// Function to find the number that occurs an odd number of times in the array
void rotate_array(int *A, int sizeA, int count)
{
    int index = 0;
    int *AA=new int[sizeA];
    int k = 0;
    for (int i = 0; i <= count; i++)
    {
        for (int j = 0; j < sizeA; j++)
        {
            index = (i + j) % sizeA;
             AA[j]=A[index];
        }
        cout << "Rotated once:"<<"\n";
               for (int k = 0; k < sizeA; k++)
        {
            cout << AA[k] << "\t";
        }
        cout<<"\n";
    }
    cout<<"\n";
}

int main()
{
    int A[] = {1, 2, 3, 4, 5};            // Example array
    int sizeA = sizeof(A) / sizeof(A[0]); // Calculate the size of the array

    rotate_array(A, sizeA, 3);

    return 0;
}
