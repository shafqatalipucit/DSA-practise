#include <iostream>
using namespace std;

// Function to check if any two elements in the array have a product equal to a given key
bool product(int *A, int size, int key)
{
    int product = 1; // Initialize product variable
    bool flag = false; // Initialize flag variable to indicate if the product is found
    for (int j = 0; j < size; j++)
    {
        product = A[j]; // Set product to the current element
        if (product == key)
        {
            flag = true; // If product is equal to key, set flag to true and return
            return flag;
        }
        for (int i = j + 1; i < size; i++)
        {
            product = product * A[0]; // Multiply product with the first element of the array
            if (product == key)
            {
                flag = true; // If product is equal to key, set flag to true and return
                return flag;
            }
        }
    }
    return flag; // Return flag indicating whether product is found or not
}

int main()
{
    int A[] = {1, 2, 3, 4, 5, 5};
    int size = sizeof(A) / sizeof(A[0]); // Calculate the size of the array
    bool result = product(A, size, 5); // Call the product function to check if product exists
    if (result == true)
    {
        cout << "Found" << "\n"; // If product exists, print "Found"
    }
    else
    {
        cout << "Not found" << "\n"; // If product doesn't exist, print "Not found"
    }
    return 0;
}
