#include <iostream>
using namespace std;

// Function to find if a given element exists in the array
bool findElement(int *A, int size, int key)
{
    bool flag = false; // Flag to track if the element is found
    // Iterate through the array elements
    for(int i = 0; i < size; i++)
    {
        // Check if the current element matches the key
        if(key == A[i])
        {
            flag = true; // Set flag to true if found
            break; // Break out of the loop since the element is found
        }
    }
    return flag; // Return the flag indicating if the element is found or not
}

int main()
{
    int A[] = {1, 2, 3, 4, 5, 5};
    int size = sizeof(A) / sizeof(A[0]); // Calculate the size of the array
    bool found = findElement(A, size, 4); // Call the function to find if 4 exists in the array
    // Check if the element is found and print appropriate message
    if(found)
    {
        cout << "Element found" << endl;
    }
    else
    {
        cout << "Element not found" << endl;
    }
    return 0;
}
