#include <iostream>
using namespace std;

// Function to recursively search for an element in a sorted array
// Parameters:
// - A: Pointer to the array
// - left: Index of the left boundary of the search space
// - right: Index of the right boundary of the search space
// - key: Element to search for
// Returns:
// - true if the element is found, false otherwise
bool findElement(int *A, int left, int right, int key)
{
    bool flag = false;
    
    // Calculate the middle index
    int mid = left + (right - left) / 2;
    
    // If the middle element is the key, return true
    if (A[mid] == key)
    {
        return flag = true;
    }
    // If the middle element is greater than the key, search in the left half
    else if (A[mid] > key)
    {
        findElement(A, left, mid, key);
    }
    // If the middle element is smaller than the key, search in the right half
    else if (A[mid] < key)
    {
        findElement(A, mid + 1, right, key);
    }
    
    return flag;
}

int main()
{
    int A[] = {1, 2, 3, 4, 5, 5};
    int size = sizeof(A) / sizeof(A[0]);  // Calculate the size of the array
    
    // Call the function to find if the element 4 exists in the array
    bool found = findElement(A, 0, size, 4); 
    
    // Check if the element is found and print an appropriate message
    if (found)
    {
        cout << "Element found" << endl;
    }
    else
    {
        cout << "Element not found" << endl;
    }
    
    return 0;
}
