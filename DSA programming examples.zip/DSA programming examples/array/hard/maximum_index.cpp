#include <iostream>
using namespace std;

// Function to find the split point in an array
int splitPoint(int *A, int size)
{
    int left = 0, right = 0;
    for (int i = 0; i < size; i++)
    {
        left = left + A[i]; // Sum of elements from the start till the current index i
        right = 0; // Resetting the right sum for each i
        for (int j = i + 1; j < size; j++)
        {
            right = right + A[j]; // Sum of elements from index i+1 till the end
        }

        if (left == right) // If the left sum is equal to the right sum, return the index
        {
            return i + 1;
        }
    }
    return -1; // If no split point is found, return -1
}

// Function to print the left and right subarrays after splitting
void print(int *A, int size)
{
    int result = splitPoint(A, size); // Find the split point
    if (result == -1)
    {
        cout << "Splitting is not possible"
             << "\n"; // If no split point is found, print a message
    }
    else
    {
        cout << "Left subarray is :"
             << "\n"; // Print left subarray
        for (int i = 0; i < result; i++)
        {
            cout << A[i] << "\t"; // Print each element of the left subarray
        }
        cout << "\n";
        cout << "Right subarray is :"
             << "\n"; // Print right subarray
        for (int j = result; j < size; j++)
        {
            cout << A[j] << "\t"; // Print each element of the right subarray
        }
        cout << "\n";
    }
}

int main()
{
    int A[] = {1, 2, 3, 4, 5, 5};
    int size = sizeof(A) / sizeof(A[0]); // Calculate the size of the array
    print(A, size); // Call the print function to find and print the split point
    return 0;
}
